-------------
Eclipse Jetty 
-------------

"Jetty provides an HTTP server, HTTP client, and javax.servlet container. 
These components are open source and available for commercial use and 
distribution."

For more information:
http://www.eclipse.org/jetty/