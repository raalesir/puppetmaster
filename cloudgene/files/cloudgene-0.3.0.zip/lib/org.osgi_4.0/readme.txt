-----------------------------------------
OSGi - The Dynamic Module System for Java
-----------------------------------------

"OSGi technology is Universal Middleware. OSGi technology provides a 
service-oriented, component-based environment for developers and offers 
standardized ways to manage the software lifecycle. These capabilities 
greatly increase the value of a wide range of computers and devices that 
use the Java platform. "

For more information:
http://www.osgi.org/